import assert from 'node:assert/strict'
import { createHmac } from 'node:crypto'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { tmpdir } from 'node:os'
import { test } from 'node:test'
import { createApp, normalizeCashfreeStatus, normalizeIndianPhone } from '../src/app.js'
import { DOCUMENTED_CASHFREE_API_VERSION, loadConfig } from '../src/config.js'
import { loadBackendEnvironment } from '../src/environment.js'
import { FileOrderStore } from '../src/store.js'

const MAIN_ORIGIN = 'http://localhost:5173'
const PAY_ORIGIN = 'http://localhost:5174'
const CHECKOUT_SECRET = 'local-reference-secret-that-is-long-enough'
const CASHFREE_SECRET = 'cashfree-test-secret'

function testConfig(overrides = {}) {
  return {
    nodeEnv: 'test',
    port: 3000,
    host: '127.0.0.1',
    mainSiteUrl: 'https://deskpay.in',
    paymentSiteUrl: 'https://pay.deskpay.in',
    cashfreeWebhookUrl: 'https://payments-test.ngrok-free.app/api/webhooks/cashfree',
    allowedOrigins: new Set([MAIN_ORIGIN, PAY_ORIGIN]),
    cashfreeClientId: 'cashfree-test-id',
    cashfreeClientSecret: CASHFREE_SECRET,
    cashfreeApiVersion: DOCUMENTED_CASHFREE_API_VERSION,
    cashfreeApiVersionProvided: true,
    cashfreeEnv: 'PRODUCTION',
    checkoutReferenceSecret: CHECKOUT_SECRET,
    orderCreationAllowedIps: new Set(['127.0.0.1', '::1']),
    dataFile: '',
    ...overrides,
  }
}

async function createHarness(t, { config: configOverrides = {}, fetchImpl: providedFetch } = {}) {
  const directory = await mkdtemp(path.join(tmpdir(), 'deskpay-api-test-'))
  const store = new FileOrderStore(path.join(directory, 'orders.json'))
  await store.initialize()

  let createdOrder = null
  let remoteOrderStatus = 'ACTIVE'
  let payments = []
  const upstreamCalls = []
  const fetchImpl = providedFetch || (async (url, options) => {
    const method = options.method
    const pathname = new URL(url).pathname
    upstreamCalls.push({ url: String(url), method, options })

    if (pathname.endsWith('/pg/orders') && method === 'POST') {
      createdOrder = JSON.parse(options.body)
      return Response.json({
        order_id: createdOrder.order_id,
        order_amount: 1,
        order_currency: 'INR',
        payment_session_id: 'mock_payment_session_for_tests',
        order_status: 'ACTIVE',
      })
    }
    if (pathname.endsWith('/payments')) return Response.json(payments)
    if (pathname.includes('/pg/orders/')) {
      return Response.json({
        order_id: createdOrder?.order_id,
        order_amount: 1,
        order_currency: 'INR',
        order_status: remoteOrderStatus,
      })
    }
    return Response.json({ message: 'Unexpected mock request' }, { status: 500 })
  })

  const config = testConfig(configOverrides)
  const app = createApp({ config, store, fetchImpl })
  const server = app.listen(0, '127.0.0.1')
  await new Promise((resolve) => server.once('listening', resolve))
  const address = server.address()
  const baseUrl = `http://127.0.0.1:${address.port}`

  t.after(async () => {
    server.closeAllConnections()
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
    await rm(directory, { recursive: true, force: true })
  })

  return {
    app,
    baseUrl,
    config,
    store,
    upstreamCalls,
    get createdOrder() { return createdOrder },
    setRemoteOrderStatus(value) { remoteOrderStatus = value },
    setPayments(value) { payments = value },
    async request(url, options = {}, origin = MAIN_ORIGIN) {
      const headers = new Headers(options.headers || {})
      if (origin) headers.set('Origin', origin)
      return fetch(`${baseUrl}${url}`, { ...options, headers })
    },
  }
}

async function createLiveOrder(harness, body = { customerPhone: '9876543210' }) {
  const response = await harness.request('/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  return { response, data: await response.json() }
}

test('uses the documented Cashfree API version when the env value is blank', () => {
  const config = loadConfig({ CASHFREE_API_VERSION: '', CASHFREE_ENV: 'PRODUCTION' })
  assert.equal(config.cashfreeApiVersion, '2026-01-01')
  assert.equal(config.cashfreeApiVersionProvided, false)
  assert.throws(
    () => loadConfig({ CASHFREE_API_VERSION: '2025-01-01' }),
    /validated for Cashfree API version 2026-01-01/,
  )
  assert.throws(
    () => loadConfig({ CASHFREE_API_VERSION: 'not-a-date' }),
    /YYYY-MM-DD/,
  )
})

test('loads production Cashfree credentials only from the selected backend env file', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'deskpay-env-test-'))
  const envFile = path.join(directory, '.env')
  const target = {
    CASHFREE_CLIENT_ID: 'shell-client-id-must-not-be-used',
    CASHFREE_CLIENT_SECRET: 'shell-secret-must-not-be-used',
  }
  t.after(() => rm(directory, { recursive: true, force: true }))

  await writeFile(envFile, 'CASHFREE_CLIENT_ID=file-client-id\nCASHFREE_CLIENT_SECRET=file-secret\n')
  loadBackendEnvironment({ env: target, envFile })
  assert.equal(target.CASHFREE_CLIENT_ID, 'file-client-id')
  assert.equal(target.CASHFREE_CLIENT_SECRET, 'file-secret')

  loadBackendEnvironment({ env: target, envFile: path.join(directory, 'missing.env') })
  assert.equal(target.CASHFREE_CLIENT_ID, '')
  assert.equal(target.CASHFREE_CLIENT_SECRET, '')
})

test('validates the optional HTTPS webhook URL', () => {
  const config = loadConfig({
    CASHFREE_API_VERSION: DOCUMENTED_CASHFREE_API_VERSION,
    CASHFREE_WEBHOOK_URL: 'https://payments-test.ngrok-free.app/api/webhooks/cashfree',
  })
  assert.equal(config.cashfreeWebhookUrl, 'https://payments-test.ngrok-free.app/api/webhooks/cashfree')
  assert.throws(
    () => loadConfig({ CASHFREE_WEBHOOK_URL: 'http://localhost:3000/api/webhooks/cashfree' }),
    /public HTTPS URL/,
  )
  assert.throws(
    () => loadConfig({ CASHFREE_WEBHOOK_URL: 'https://example.com/other-path' }),
    /public HTTPS URL/,
  )
})

test('normalizes valid Indian mobile numbers and rejects invalid ones', () => {
  assert.equal(normalizeIndianPhone('98765 43210'), '+919876543210')
  assert.equal(normalizeIndianPhone('+919876543210'), '+919876543210')
  assert.equal(normalizeIndianPhone('1234567890'), null)
  assert.equal(normalizeIndianPhone('98765432101234567890'), null)
})

test('creates a Cashfree order using only the server-set amount and customer phone', async (t) => {
  const harness = await createHarness(t)
  const { response, data } = await createLiveOrder(harness)

  assert.equal(response.status, 201)
  assert.equal(data.amount, 1)
  assert.equal(data.currency, 'INR')
  assert.match(data.orderId, /^dp_[a-f0-9]{32}$/)
  assert.match(data.checkoutReference, /^[A-Za-z0-9_-]{43}$/)
  assert.match(data.checkoutUrl, /^http:\/\/localhost:5174\/?\?ref=/)
  assert.equal(Object.hasOwn(data, 'paymentSessionId'), false)
  assert.equal(harness.createdOrder.order_amount, 1)
  assert.equal(harness.createdOrder.order_currency, 'INR')
  assert.equal(harness.createdOrder.customer_details.customer_phone, '+919876543210')
  assert.equal(harness.createdOrder.order_meta.return_url.includes(data.checkoutReference), true)
  assert.equal(
    harness.createdOrder.order_meta.return_url,
    `https://pay.deskpay.in/?ref=${data.checkoutReference}&order_id={order_id}`,
  )
  assert.equal(
    harness.createdOrder.order_meta.notify_url,
    'https://payments-test.ngrok-free.app/api/webhooks/cashfree',
  )
  assert.equal(harness.upstreamCalls[0].url, 'https://api.cashfree.com/pg/orders')
  assert.equal(harness.upstreamCalls[0].options.headers['x-api-version'], '2026-01-01')
  assert.equal(harness.upstreamCalls[0].options.headers['x-client-secret'], CASHFREE_SECRET)
})

test('rejects client-provided amount, product, and malformed phone without contacting Cashfree', async (t) => {
  const harness = await createHarness(t)
  const amountInjection = await createLiveOrder(harness, {
    customerPhone: '9876543210',
    amount: 1000,
  })
  assert.equal(amountInjection.response.status, 400)
  assert.match(amountInjection.data.error, /amount are fixed by the server/)

  const productInjection = await createLiveOrder(harness, {
    customerPhone: '9876543210',
    productId: 'other-product',
  })
  assert.equal(productInjection.response.status, 400)

  const invalidPhone = await createLiveOrder(harness, { customerPhone: '1234567890' })
  assert.equal(invalidPhone.response.status, 400)
  assert.equal(harness.upstreamCalls.length, 0)
})

test('reports Cashfree configuration presence as booleans and does not expose credentials', async (t) => {
  const harness = await createHarness(t)
  const response = await harness.request('/api/config/status')
  const data = await response.json()
  assert.deepEqual(data.cashfree, {
    clientIdConfigured: true,
    clientSecretConfigured: true,
    webhookUrlConfigured: true,
    apiVersionVariablePresent: true,
    documentedApiVersionDefaultAvailable: true,
  })
  assert.equal(JSON.stringify(data).includes(CASHFREE_SECRET), false)
  assert.equal(JSON.stringify(data).includes('cashfree-test-id'), false)
})

test('returns a useful error without revealing Cashfree response details for rejected credentials', async (t) => {
  const harness = await createHarness(t, {
    fetchImpl: async () => Response.json({ message: 'private upstream response marker' }, { status: 401 }),
  })
  const { response, data } = await createLiveOrder(harness)
  assert.equal(response.status, 502)
  assert.match(data.error, /rejected the server credentials/)
  assert.equal(JSON.stringify(data).includes('private upstream response marker'), false)
})

test('does not call Cashfree when credentials are missing', async (t) => {
  const harness = await createHarness(t, {
    config: { cashfreeClientId: '', cashfreeClientSecret: '' },
  })
  const { response, data } = await createLiveOrder(harness)
  assert.equal(response.status, 503)
  assert.match(data.error, /not configured/)
  assert.equal(harness.upstreamCalls.length, 0)
})

test('checkout references resolve only to the stored order and checkout session', async (t) => {
  const harness = await createHarness(t)
  const { data } = await createLiveOrder(harness)
  const resolved = await harness.request(`/api/checkout/${data.checkoutReference}`, {}, PAY_ORIGIN)
  const resolvedBody = await resolved.json()
  assert.equal(resolved.status, 200)
  assert.equal(resolvedBody.orderId, data.orderId)
  assert.equal(resolvedBody.productName, 'Deskpay Demo Product')
  assert.equal(resolvedBody.amount, 1)
  assert.equal(resolvedBody.currency, 'INR')
  assert.equal(resolvedBody.paymentSessionId, 'mock_payment_session_for_tests')

  const unknown = await harness.request(`/api/checkout/${'A'.repeat(43)}`, {}, PAY_ORIGIN)
  assert.equal(unknown.status, 404)
})

test('rejects expired or malformed checkout references while retaining recent status access', async (t) => {
  const harness = await createHarness(t)
  const { data: created } = await createLiveOrder(harness)
  await harness.store.updateOrder(created.orderId, {
    referenceExpiresAt: new Date(Date.now() - 1_000).toISOString(),
  })

  const expiredCheckout = await harness.request(
    `/api/checkout/${created.checkoutReference}`,
    {},
    PAY_ORIGIN,
  )
  assert.equal(expiredCheckout.status, 404)

  const expiredStatus = await harness.request(`/api/orders/${created.orderId}/status`, {
    headers: { 'X-Checkout-Reference': created.checkoutReference },
  }, PAY_ORIGIN)
  assert.equal(expiredStatus.status, 200)

  await harness.store.updateOrder(created.orderId, { createdAt: 'not-a-date' })
  const malformedStatus = await harness.request(`/api/orders/${created.orderId}/status`, {
    headers: { 'X-Checkout-Reference': created.checkoutReference },
  }, PAY_ORIGIN)
  assert.equal(malformedStatus.status, 404)
})

test('status reports PAID only after matching captured payment details are verified', async (t) => {
  const harness = await createHarness(t)
  const { data: created } = await createLiveOrder(harness)
  harness.setRemoteOrderStatus('PAID')
  harness.setPayments([{
    order_id: created.orderId,
    order_amount: 1,
    order_currency: 'INR',
    payment_status: 'SUCCESS',
    is_captured: true,
    payment_amount: 1,
    payment_currency: 'INR',
  }])

  const response = await harness.request(`/api/orders/${created.orderId}/status`, {
    headers: { 'X-Checkout-Reference': created.checkoutReference },
  }, PAY_ORIGIN)
  const data = await response.json()
  assert.equal(response.status, 200)
  assert.equal(data.status, 'PAID')

  harness.setPayments([{
    order_id: created.orderId,
    order_amount: 1,
    order_currency: 'INR',
    payment_status: 'SUCCESS',
    is_captured: true,
    payment_amount: 2,
    payment_currency: 'INR',
  }])
  const mismatch = await harness.request(`/api/orders/${created.orderId}/status`, {
    headers: { 'X-Checkout-Reference': created.checkoutReference },
  }, PAY_ORIGIN)
  assert.equal((await mismatch.json()).status, 'PENDING')
})

test('requires matching order ID and checkout reference for status access', async (t) => {
  const harness = await createHarness(t)
  const { data } = await createLiveOrder(harness)
  const invalidId = await harness.request('/api/orders/not-an-order/status', {
    headers: { 'X-Checkout-Reference': data.checkoutReference },
  })
  assert.equal(invalidId.status, 400)

  const unauthorized = await harness.request(`/api/orders/${data.orderId}/status`)
  assert.equal(unauthorized.status, 401)
})

test('rejects an unapproved browser origin', async (t) => {
  const harness = await createHarness(t)
  const response = await harness.request('/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ customerPhone: '9876543210' }),
  }, 'https://attacker.invalid')
  assert.equal(response.status, 403)
  assert.equal(harness.upstreamCalls.length, 0)
})

test('CORS preflight allows the ngrok interstitial bypass header used by the hosted pages', async (t) => {
  const harness = await createHarness(t)
  const response = await harness.request('/api/checkout/placeholder', {
    method: 'OPTIONS',
    headers: { 'Access-Control-Request-Headers': 'ngrok-skip-browser-warning' },
  }, PAY_ORIGIN)
  assert.equal(response.status, 204)
  assert.match(response.headers.get('access-control-allow-headers'), /ngrok-skip-browser-warning/i)
})

test('restricts tunneled order creation to the forwarded tester IP allowlist', async (t) => {
  const harness = await createHarness(t, {
    config: { orderCreationAllowedIps: new Set(['198.51.100.42']) },
  })
  const makeRequest = (forwardedIp) => harness.request('/api/orders', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Forwarded-For': forwardedIp,
    },
    body: JSON.stringify({ customerPhone: '9876543210' }),
  })

  assert.equal((await makeRequest('198.51.100.42')).status, 201)
  assert.equal((await makeRequest('203.0.113.77')).status, 403)
  assert.equal(harness.upstreamCalls.filter((call) => call.method === 'POST').length, 1)
})

test('Cashfree webhook signature uses timestamp and exact raw body, and repeated events are idempotent', async (t) => {
  const harness = await createHarness(t)
  const { data: created } = await createLiveOrder(harness)
  const timestamp = String(Date.now())
  const rawBody = JSON.stringify({
    type: 'PAYMENT_FAILED_WEBHOOK',
    data: {
      order: { order_id: created.orderId, order_amount: 1, order_currency: 'INR' },
      payment: { payment_status: 'FAILED', payment_amount: 1, payment_currency: 'INR' },
    },
    event_time: new Date().toISOString(),
  })
  const signature = createHmac('sha256', CASHFREE_SECRET)
    .update(`${timestamp}${rawBody}`)
    .digest('base64')

  const postWebhook = () => fetch(`${harness.baseUrl}/api/webhooks/cashfree`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-webhook-timestamp': timestamp,
      'x-webhook-signature': signature,
    },
    body: rawBody,
  })
  const first = await postWebhook()
  assert.equal(first.status, 200)
  assert.deepEqual(await first.json(), { received: true, duplicate: false })

  const repeated = await postWebhook()
  assert.equal(repeated.status, 200)
  assert.deepEqual(await repeated.json(), { received: true, duplicate: true })

  const invalid = await fetch(`${harness.baseUrl}/api/webhooks/cashfree`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-webhook-timestamp': timestamp },
    body: rawBody,
  })
  assert.equal(invalid.status, 401)
})

test('success webhook records PAID only after Cashfree API confirms a matching captured payment', async (t) => {
  const harness = await createHarness(t)
  const { data: created } = await createLiveOrder(harness)
  harness.setRemoteOrderStatus('PAID')
  harness.setPayments([{
    order_id: created.orderId,
    order_amount: 1,
    order_currency: 'INR',
    payment_status: 'SUCCESS',
    is_captured: true,
    payment_amount: 1,
    payment_currency: 'INR',
  }])

  const timestamp = String(Date.now())
  const rawBody = JSON.stringify({
    type: 'PAYMENT_SUCCESS_WEBHOOK',
    data: {
      order: { order_id: created.orderId, order_amount: 1, order_currency: 'INR' },
      payment: {
        payment_status: 'SUCCESS',
        order_amount: 1,
        order_currency: 'INR',
        payment_amount: 1,
        payment_currency: 'INR',
      },
    },
    event_time: new Date().toISOString(),
  })
  const signature = createHmac('sha256', CASHFREE_SECRET)
    .update(`${timestamp}${rawBody}`)
    .digest('base64')
  const response = await fetch(`${harness.baseUrl}/api/webhooks/cashfree`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-webhook-timestamp': timestamp,
      'x-webhook-signature': signature,
    },
    body: rawBody,
  })
  assert.equal(response.status, 200)
  assert.deepEqual(await response.json(), { received: true, duplicate: false })

  const savedOrder = await harness.store.getOrder(created.orderId)
  assert.equal(savedOrder.lastVerifiedStatus, 'PAID')
  assert.equal(savedOrder.lastWebhook.type, 'PAYMENT_SUCCESS_WEBHOOK')
  assert.equal(harness.upstreamCalls.filter((call) => call.method === 'GET').length, 2)
})

test('webhook order and payment amounts must match the local INR order', async (t) => {
  const harness = await createHarness(t)
  const { data: created } = await createLiveOrder(harness)
  const timestamp = String(Date.now())
  const rawBody = JSON.stringify({
    type: 'PAYMENT_FAILED_WEBHOOK',
    data: {
      order: { order_id: created.orderId, order_amount: 1, order_currency: 'INR' },
      payment: { payment_status: 'FAILED', payment_amount: 99, payment_currency: 'INR' },
    },
  })
  const signature = createHmac('sha256', CASHFREE_SECRET)
    .update(`${timestamp}${rawBody}`)
    .digest('base64')
  const response = await fetch(`${harness.baseUrl}/api/webhooks/cashfree`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-webhook-timestamp': timestamp,
      'x-webhook-signature': signature,
    },
    body: rawBody,
  })
  assert.equal(response.status, 400)
})

test('normalizes only matching captured successes to PAID', () => {
  const localOrder = { orderId: 'dp_0123456789abcdef0123456789abcdef' }
  const order = {
    order_id: localOrder.orderId,
    order_amount: 1,
    order_currency: 'INR',
    order_status: 'PAID',
  }
  const matchingCapture = [{
    order_id: localOrder.orderId,
    order_amount: 1,
    order_currency: 'INR',
    payment_status: 'SUCCESS',
    is_captured: true,
    payment_amount: 1,
    payment_currency: 'INR',
  }]
  assert.equal(normalizeCashfreeStatus({ order, payments: matchingCapture, localOrder }).status, 'PAID')
  assert.equal(normalizeCashfreeStatus({ order, payments: [], localOrder }).status, 'PENDING')
  assert.equal(
    normalizeCashfreeStatus({ order: { ...order, order_currency: 'USD' }, payments: matchingCapture, localOrder }).status,
    'FAILED',
  )
})
