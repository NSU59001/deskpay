import test from 'node:test'
import assert from 'node:assert/strict'
import { formatStartupError } from '../src/startup-error.js'

test('formats actionable configuration errors without exposing arbitrary error details', () => {
  const secret = 'do-not-print-this-secret'
  const output = formatStartupError(new Error(`configuration included ${secret}`), 'configuration', {
    envFile: 'C:\\Deskpay\\backend\\.env',
  })

  assert.match(output, /startup failed during configuration \(Error\)/)
  assert.match(output, /Backend configuration validation failed/)
  assert.match(output, /C:\\Deskpay\\backend\\\.env/)
  assert.doesNotMatch(output, new RegExp(secret))
})

test('reports the known webhook validation message without printing configuration values', () => {
  const output = formatStartupError(
    new Error('CASHFREE_WEBHOOK_URL must be a public HTTPS URL ending in /api/webhooks/cashfree.'),
    'configuration',
    { envFile: 'C:\\Deskpay\\backend\\.env' },
  )

  assert.match(output, /CASHFREE_WEBHOOK_URL must be a public HTTPS URL/)
})

test('reports a safe store path and actionable disk permission guidance', () => {
  const output = formatStartupError(Object.assign(new Error('private detail'), { code: 'EACCES' }), 'local order store', {
    storePath: `${process.cwd()}\\..\\data\\orders.json`,
  })

  assert.match(output, /EACCES/)
  assert.match(output, /not writable/)
  assert.match(output, /orders\.json/)
  assert.doesNotMatch(output, /private detail/)
})
