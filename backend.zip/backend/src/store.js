import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

const emptyState = () => ({ version: 1, orders: {}, processedWebhookEvents: [] })

export class FileOrderStore {
  #state = emptyState()
  #writeQueue = Promise.resolve()

  constructor(filePath) {
    this.filePath = filePath
  }

  async initialize() {
    await mkdir(path.dirname(this.filePath), { recursive: true })
    try {
      const parsed = JSON.parse(await readFile(this.filePath, 'utf8'))
      if (
        parsed?.version !== 1 ||
        !parsed.orders ||
        typeof parsed.orders !== 'object' ||
        !Array.isArray(parsed.processedWebhookEvents)
      ) {
        throw new Error('The local order store has an unsupported or invalid format.')
      }
      this.#state = parsed
    } catch (error) {
      if (error.code !== 'ENOENT') throw error
      await this.#persist(this.#state)
    }
  }

  async getOrder(orderId) {
    await this.#writeQueue
    const order = this.#state.orders[orderId]
    return order ? structuredClone(order) : null
  }

  async findOrderByReferenceDigest(referenceDigest) {
    await this.#writeQueue
    const order = Object.values(this.#state.orders).find(
      (candidate) => candidate.referenceDigest === referenceDigest,
    )
    return order ? structuredClone(order) : null
  }

  async createOrder(order) {
    return this.#serialize(async (nextState) => {
      if (nextState.orders[order.orderId]) {
        throw new Error('An order with this ID already exists in the local store.')
      }
      nextState.orders[order.orderId] = structuredClone(order)
    })
  }

  async updateOrder(orderId, updates) {
    return this.#serialize(async (nextState) => {
      const order = nextState.orders[orderId]
      if (!order) return null
      Object.assign(order, structuredClone(updates))
      return structuredClone(order)
    })
  }

  async processWebhookEvent(eventDigest, orderId, updates) {
    return this.#serialize(async (nextState) => {
      if (nextState.processedWebhookEvents.includes(eventDigest)) {
        return { duplicate: true, order: null }
      }

      const order = nextState.orders[orderId]
      if (!order) return { duplicate: false, order: null }

      Object.assign(order, structuredClone(updates))
      nextState.processedWebhookEvents.push(eventDigest)
      if (nextState.processedWebhookEvents.length > 2000) {
        nextState.processedWebhookEvents.splice(0, nextState.processedWebhookEvents.length - 2000)
      }

      return { duplicate: false, order: structuredClone(order) }
    })
  }

  #serialize(operation) {
    const next = this.#writeQueue.then(async () => {
      const nextState = structuredClone(this.#state)
      const result = await operation(nextState)
      await this.#persist(nextState)
      this.#state = nextState
      return result
    })
    this.#writeQueue = next.catch(() => {})
    return next
  }

  async #persist(state) {
    const temporaryPath = `${this.filePath}.${process.pid}.${randomUUID()}.tmp`
    try {
      await writeFile(temporaryPath, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 })
      await rename(temporaryPath, this.filePath)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }
}
