import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto'
import express from 'express'
import rateLimit from 'express-rate-limit'
import {
  CHECKOUT_STATUS_RETENTION_MS,
  CHECKOUT_REFERENCE_TTL_MS,
} from './config.js'
import { CashfreeError, createCashfreeClient } from './cashfree.js'

const PRODUCT_NAME = 'Deskpay Demo Product'
const ORDER_AMOUNT = 1
const ORDER_CURRENCY = 'INR'
const ORDER_ID_PATTERN = /^dp_[a-f0-9]{32}$/
const REFERENCE_PATTERN = /^[A-Za-z0-9_-]{43}$/

function normalizeIp(address = '') {
  return address.replace(/^::ffff:/i, '')
}

function createReferenceDigest(reference, secret) {
  return createHmac('sha256', secret).update(reference).digest('hex')
}

export function normalizeIndianPhone(value) {
  if (typeof value !== 'string' || value.length > 24) return null
  const compact = value.trim().replace(/[\s().-]/g, '')
  if (!/^\+?(?:91)?[6-9]\d{9}$/.test(compact)) return null
  const digits = compact.replace(/^\+/, '')
  return digits.startsWith('91') ? `+${digits}` : `+91${digits}`
}

export function verifyCashfreeWebhookSignature(signature, rawBody, timestamp, secret) {
  if (
    typeof signature !== 'string' ||
    typeof timestamp !== 'string' ||
    !/^\d{10,16}$/.test(timestamp) ||
    typeof rawBody !== 'string' ||
    !secret
  ) {
    return false
  }

  const expected = createHmac('sha256', secret)
    .update(`${timestamp}${rawBody}`, 'utf8')
    .digest('base64')
  const expectedBytes = Buffer.from(expected, 'utf8')
  const receivedBytes = Buffer.from(signature, 'utf8')
  return (
    expectedBytes.length === receivedBytes.length &&
    timingSafeEqual(expectedBytes, receivedBytes)
  )
}

function isExpectedAmount(value) {
  return typeof value === 'number' && Number.isFinite(value) && value === ORDER_AMOUNT
}

function isCashfreeConfigured(config) {
  return Boolean(config.cashfreeClientId && config.cashfreeClientSecret)
}

function isAllowedOrigin(config, origin) {
  return typeof origin === 'string' && config.allowedOrigins.has(origin)
}

function paymentSiteForRequest(config, origin) {
  if (!origin) return config.paymentSiteUrl
  try {
    const source = new URL(origin)
    if (
      ['localhost', '127.0.0.1'].includes(source.hostname) &&
      [5173, 5174].includes(Number(source.port))
    ) {
      return `${source.protocol}//${source.hostname}:5174`
    }
  } catch {
    // The strict origin check will reject malformed origins before this helper is used.
  }
  return config.paymentSiteUrl
}

function ensureFrontendOrigin(req, res, next, config) {
  const origin = req.get('origin')
  if (!isAllowedOrigin(config, origin)) {
    return res.status(403).json({ error: 'This website origin is not allowed.' })
  }
  return next()
}

function parseCreateOrderBody(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { error: 'Send a JSON object with customerPhone.' }
  }
  const keys = Object.keys(body)
  if (keys.length !== 1 || keys[0] !== 'customerPhone') {
    return { error: 'Only customerPhone is accepted. Product and amount are fixed by the server.' }
  }
  const customerPhone = normalizeIndianPhone(body.customerPhone)
  if (!customerPhone) {
    return { error: 'Enter a valid 10-digit Indian mobile number.' }
  }
  return { customerPhone }
}

function readPaymentAttempt(payments) {
  if (!Array.isArray(payments)) return null
  return [...payments]
    .filter((payment) => payment && typeof payment === 'object')
    .sort((left, right) => {
      const leftTime = left.payment_completion_time || left.payment_time || ''
      const rightTime = right.payment_completion_time || right.payment_time || ''
      return String(leftTime).localeCompare(String(rightTime))
    })
    .at(-1) || null
}

export function normalizeCashfreeStatus({ order, payments, localOrder, now = Date.now() }) {
  if (
    !order ||
    order.order_id !== localOrder.orderId ||
    !isExpectedAmount(order.order_amount) ||
    order.order_currency !== ORDER_CURRENCY
  ) {
    return {
      status: 'FAILED',
      message: 'Cashfree returned order details that do not match the expected ₹1.00 INR order.',
    }
  }

  const matchingAttempts = Array.isArray(payments)
    ? payments.filter((payment) => payment?.order_id === localOrder.orderId)
    : []
  const verifiedCapture = matchingAttempts.some(
    (payment) =>
      payment.payment_status === 'SUCCESS' &&
      payment.is_captured === true &&
      payment.order_currency === ORDER_CURRENCY &&
      isExpectedAmount(payment.order_amount) &&
      payment.payment_currency === ORDER_CURRENCY &&
      isExpectedAmount(payment.payment_amount),
  )

  if (order.order_status === 'PAID' && verifiedCapture) {
    return { status: 'PAID', message: 'Cashfree verified a captured ₹1.00 INR payment.' }
  }

  if (order.order_status === 'EXPIRED' || order.order_status === 'TERMINATED') {
    return { status: 'EXPIRED', message: 'This Cashfree order has expired.' }
  }

  if (order.order_expiry_time && Date.parse(order.order_expiry_time) <= now) {
    return { status: 'EXPIRED', message: 'This Cashfree order has expired.' }
  }

  if (
    matchingAttempts.some(
      (payment) =>
        payment.payment_status === 'SUCCESS' &&
        (!payment.is_captured ||
          payment.order_currency !== ORDER_CURRENCY ||
          !isExpectedAmount(payment.order_amount) ||
          payment.payment_currency !== ORDER_CURRENCY ||
          !isExpectedAmount(payment.payment_amount)),
    )
  ) {
    return {
      status: 'PENDING',
      message: 'Cashfree has not yet confirmed a captured payment for the expected amount.',
    }
  }

  const latestAttempt = readPaymentAttempt(matchingAttempts)
  if (latestAttempt?.payment_status === 'PENDING') {
    return { status: 'PENDING', message: 'Cashfree is still processing the payment.' }
  }

  if (['FAILED', 'USER_DROPPED', 'CANCELLED', 'VOID'].includes(latestAttempt?.payment_status)) {
    return { status: 'FAILED', message: 'The latest Cashfree payment attempt did not complete.' }
  }

  return { status: 'PENDING', message: 'No captured payment has been verified yet.' }
}

function referenceForOrder(order, config, { allowExpired = false } = {}) {
  if (!order || !config.checkoutReferenceSecret) return false
  const referenceExpiresAt = Date.parse(order.referenceExpiresAt)
  const createdAt = Date.parse(order.createdAt)
  if (!Number.isFinite(referenceExpiresAt) || !Number.isFinite(createdAt)) return false
  if (!allowExpired && referenceExpiresAt <= Date.now()) return false
  if (
    allowExpired &&
    createdAt + CHECKOUT_STATUS_RETENTION_MS <= Date.now()
  ) {
    return false
  }
  return true
}

function buildReturnUrl(paymentSiteUrl, reference) {
  const returnUrl = new URL('/', paymentSiteUrl)
  returnUrl.searchParams.set('ref', reference)
  return `${returnUrl.toString()}&order_id={order_id}`
}

function cashfreeErrorResponse(res, error, action) {
  const upstreamStatus = error instanceof CashfreeError ? error.status : 0
  const statusCode = upstreamStatus === 401 ? 502 : 502
  const message =
    upstreamStatus === 401
      ? 'Cashfree rejected the server credentials. Check the Cashfree production API keys.'
      : upstreamStatus === 0
        ? `The server could not reach Cashfree to ${action}. Try again shortly.`
        : `Cashfree could not ${action}. Check the Cashfree dashboard and server configuration.`
  return res.status(statusCode).json({ error: message })
}

export function createApp({ config, store, fetchImpl = globalThis.fetch }) {
  const app = express()
  const cashfree = createCashfreeClient({ config, fetchImpl })

  app.disable('x-powered-by')
  app.set('trust proxy', 'loopback')

  app.use((req, res, next) => {
    const origin = req.get('origin')
    if (origin) {
      if (!isAllowedOrigin(config, origin)) {
        return res.status(403).json({ error: 'This website origin is not allowed.' })
      }
      res.setHeader('Access-Control-Allow-Origin', origin)
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
      res.setHeader(
        'Access-Control-Allow-Headers',
        'Content-Type, X-Checkout-Reference, ngrok-skip-browser-warning',
      )
      res.setHeader('Vary', 'Origin')
    }
    res.setHeader('X-Content-Type-Options', 'nosniff')
    res.setHeader('Referrer-Policy', 'no-referrer')
    res.setHeader('Cache-Control', 'no-store')
    if (req.method === 'OPTIONS') {
      if (!origin || !isAllowedOrigin(config, origin)) {
        return res.status(403).end()
      }
      return res.status(204).end()
    }
    return next()
  })

  const apiLimiter = rateLimit({
    windowMs: 60_000,
    limit: 120,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many requests. Wait a moment and try again.' },
  })
  const orderLimiter = rateLimit({
    windowMs: 10 * 60_000,
    limit: 5,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many order attempts. Wait 10 minutes and try again.' },
  })

  app.use('/api', apiLimiter)

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'deskpay-api' })
  })

  app.get('/api/config/status', (_req, res) => {
    res.json({
      cashfree: {
        clientIdConfigured: Boolean(config.cashfreeClientId),
        clientSecretConfigured: Boolean(config.cashfreeClientSecret),
        webhookUrlConfigured: Boolean(config.cashfreeWebhookUrl),
        apiVersionVariablePresent: Boolean(config.cashfreeApiVersionProvided),
        documentedApiVersionDefaultAvailable: true,
      },
    })
  })

  app.post(
    '/api/orders',
    orderLimiter,
    express.json({ limit: '2kb', strict: true }),
    (req, res, next) => ensureFrontendOrigin(req, res, next, config),
    async (req, res) => {
      const allowedAddress = config.orderCreationAllowedIps.has(normalizeIp(req.ip))
      if (!allowedAddress) {
        return res.status(403).json({
          error: 'Order creation is restricted to the configured test IPs.',
        })
      }

      const input = parseCreateOrderBody(req.body)
      if (input.error) return res.status(400).json({ error: input.error })
      if (!isCashfreeConfigured(config)) {
        return res.status(503).json({
          error: 'Cashfree production credentials are not configured on the backend.',
        })
      }
      if (!config.checkoutReferenceSecret || config.checkoutReferenceSecret.length < 32) {
        return res.status(503).json({
          error: 'The backend checkout reference secret must contain at least 32 characters.',
        })
      }

      const orderId = `dp_${randomUUID().replaceAll('-', '')}`
      const reference = randomBytes(32).toString('base64url')
      const now = Date.now()
      const paymentSiteUrl = paymentSiteForRequest(config, req.get('origin'))
      const orderRequest = {
        order_id: orderId,
        order_amount: ORDER_AMOUNT,
        order_currency: ORDER_CURRENCY,
        customer_details: {
          customer_id: `guest_${randomUUID().replaceAll('-', '').slice(0, 20)}`,
          customer_phone: input.customerPhone,
        },
        order_meta: {
          return_url: buildReturnUrl(config.paymentSiteUrl, reference),
          ...(config.cashfreeWebhookUrl ? { notify_url: config.cashfreeWebhookUrl } : {}),
        },
        order_note: PRODUCT_NAME,
      }

      let cashfreeOrder
      try {
        cashfreeOrder = await cashfree.createOrder(orderRequest)
      } catch (error) {
        return cashfreeErrorResponse(res, error, 'create the order')
      }
      if (
        cashfreeOrder?.order_id !== orderId ||
        !isExpectedAmount(cashfreeOrder.order_amount) ||
        cashfreeOrder.order_currency !== ORDER_CURRENCY ||
        typeof cashfreeOrder.payment_session_id !== 'string' ||
        !cashfreeOrder.payment_session_id
      ) {
        return res.status(502).json({
          error: 'Cashfree returned an incomplete order response. No checkout link was issued.',
        })
      }

      const record = {
        orderId,
        productName: PRODUCT_NAME,
        amount: ORDER_AMOUNT,
        currency: ORDER_CURRENCY,
        paymentSessionId: cashfreeOrder.payment_session_id,
        referenceDigest: createReferenceDigest(reference, config.checkoutReferenceSecret),
        createdAt: new Date(now).toISOString(),
        referenceExpiresAt: new Date(now + CHECKOUT_REFERENCE_TTL_MS).toISOString(),
        lastVerifiedStatus: 'PENDING',
        lastVerifiedAt: null,
        lastWebhook: null,
      }
      try {
        await store.createOrder(record)
      } catch {
        return res.status(500).json({
          error: 'Cashfree created the order, but the local record could not be saved. Do not continue to payment.',
        })
      }

      const checkoutUrl = new URL('/', paymentSiteUrl)
      checkoutUrl.searchParams.set('ref', reference)
      return res.status(201).json({
        orderId,
        checkoutReference: reference,
        checkoutUrl: checkoutUrl.toString(),
        expiresAt: record.referenceExpiresAt,
        productName: PRODUCT_NAME,
        amount: ORDER_AMOUNT,
        currency: ORDER_CURRENCY,
      })
    },
  )

  app.get(
    '/api/checkout/:reference',
    (req, res, next) => ensureFrontendOrigin(req, res, next, config),
    async (req, res) => {
      const reference = req.params.reference
      if (!REFERENCE_PATTERN.test(reference)) {
        return res.status(404).json({ error: 'This checkout link is invalid or has expired.' })
      }
      if (!config.checkoutReferenceSecret) {
        return res.status(503).json({ error: 'Checkout reference validation is not configured.' })
      }
      const order = await store.findOrderByReferenceDigest(
        createReferenceDigest(reference, config.checkoutReferenceSecret),
      )
      if (!referenceForOrder(order, config)) {
        return res.status(404).json({ error: 'This checkout link is invalid or has expired.' })
      }

      return res.json({
        orderId: order.orderId,
        productName: order.productName,
        amount: order.amount,
        currency: order.currency,
        paymentSessionId: order.paymentSessionId,
        expiresAt: order.referenceExpiresAt,
        environment: 'PRODUCTION',
      })
    },
  )

  app.get(
    '/api/orders/:orderId/status',
    (req, res, next) => ensureFrontendOrigin(req, res, next, config),
    async (req, res) => {
      const { orderId } = req.params
      if (!ORDER_ID_PATTERN.test(orderId)) {
        return res.status(400).json({ error: 'The order ID is invalid.' })
      }
      const reference = req.get('x-checkout-reference') || ''
      if (!REFERENCE_PATTERN.test(reference) || !config.checkoutReferenceSecret) {
        return res.status(401).json({ error: 'A valid checkout reference is required.' })
      }

      const [order, referenceOrder] = await Promise.all([
        store.getOrder(orderId),
        store.findOrderByReferenceDigest(
          createReferenceDigest(reference, config.checkoutReferenceSecret),
        ),
      ])
      if (
        !order ||
        referenceOrder?.orderId !== orderId ||
        !referenceForOrder(order, config, { allowExpired: true })
      ) {
        return res.status(404).json({ error: 'The order was not found for this checkout reference.' })
      }
      if (!isCashfreeConfigured(config)) {
        return res.status(503).json({
          error: 'Cashfree production credentials are not configured on the backend.',
        })
      }

      try {
        const [cashfreeOrder, payments] = await Promise.all([
          cashfree.getOrder(orderId),
          cashfree.getPayments(orderId),
        ])
        const normalized = normalizeCashfreeStatus({
          order: cashfreeOrder,
          payments,
          localOrder: order,
        })
        const verifiedAt = new Date().toISOString()
        await store.updateOrder(orderId, {
          lastVerifiedStatus: normalized.status,
          lastVerifiedAt: verifiedAt,
        })
        return res.json({
          orderId,
          productName: order.productName,
          amount: order.amount,
          currency: order.currency,
          status: normalized.status,
          message: normalized.message,
          verifiedAt,
        })
      } catch (error) {
        return cashfreeErrorResponse(res, error, 'verify the payment')
      }
    },
  )

  app.post(
    '/api/webhooks/cashfree',
    express.raw({ type: 'application/json', limit: '1mb' }),
    async (req, res) => {
      const signature = req.get('x-webhook-signature')
      const timestamp = req.get('x-webhook-timestamp')
      const rawBody = Buffer.isBuffer(req.body) ? req.body.toString('utf8') : ''
      if (
        !verifyCashfreeWebhookSignature(
          signature,
          rawBody,
          timestamp,
          config.cashfreeClientSecret,
        )
      ) {
        return res.status(401).json({ error: 'The Cashfree webhook signature is invalid.' })
      }

      let event
      try {
        event = JSON.parse(rawBody)
      } catch {
        return res.status(400).json({ error: 'The Cashfree webhook body is not valid JSON.' })
      }

      const orderData = event?.data?.order
      const paymentData = event?.data?.payment
      const orderId = orderData?.order_id
      if (
        typeof orderId !== 'string' ||
        !ORDER_ID_PATTERN.test(orderId) ||
        !isExpectedAmount(orderData?.order_amount) ||
        orderData?.order_currency !== ORDER_CURRENCY ||
        (paymentData?.payment_amount !== undefined &&
          !isExpectedAmount(paymentData.payment_amount)) ||
        (paymentData?.payment_currency !== undefined &&
          paymentData.payment_currency !== ORDER_CURRENCY) ||
        (paymentData?.order_amount !== undefined &&
          !isExpectedAmount(paymentData.order_amount)) ||
        (paymentData?.order_currency !== undefined &&
          paymentData.order_currency !== ORDER_CURRENCY)
      ) {
        return res.status(400).json({ error: 'The webhook order details are invalid.' })
      }

      const localOrder = await store.getOrder(orderId)
      if (
        !localOrder ||
        localOrder.amount !== orderData.order_amount ||
        localOrder.currency !== orderData.order_currency
      ) {
        return res.status(400).json({ error: 'The webhook does not match a local order.' })
      }

      const eventDigest = createHash('sha256').update(rawBody).digest('hex')
      const isSuccessEvent =
        event?.type === 'PAYMENT_SUCCESS_WEBHOOK' && paymentData?.payment_status === 'SUCCESS'
      let verifiedUpdate = {}

      if (isSuccessEvent) {
        try {
          const [cashfreeOrder, payments] = await Promise.all([
            cashfree.getOrder(orderId),
            cashfree.getPayments(orderId),
          ])
          const normalized = normalizeCashfreeStatus({
            order: cashfreeOrder,
            payments,
            localOrder,
          })
          verifiedUpdate = {
            lastVerifiedStatus: normalized.status,
            lastVerifiedAt: new Date().toISOString(),
          }
        } catch (error) {
          return cashfreeErrorResponse(res, error, 'verify the webhook payment')
        }
      }

      const processed = await store.processWebhookEvent(eventDigest, orderId, {
        ...verifiedUpdate,
        lastWebhook: {
          type: typeof event?.type === 'string' ? event.type.slice(0, 80) : 'UNKNOWN',
          paymentStatus:
            typeof paymentData?.payment_status === 'string'
              ? paymentData.payment_status.slice(0, 30)
              : null,
          receivedAt: new Date().toISOString(),
        },
      })
      if (!processed.order && !processed.duplicate) {
        return res.status(400).json({ error: 'The webhook order no longer exists.' })
      }
      return res.status(200).json({ received: true, duplicate: processed.duplicate })
    },
  )

  app.use(express.json({ limit: '2kb', strict: true }))
  app.use((_req, res) => res.status(404).json({ error: 'Route not found.' }))
  app.use((error, _req, res, _next) => {
    if (error?.type === 'entity.parse.failed') {
      return res.status(400).json({ error: 'Request body must be valid JSON.' })
    }
    if (error?.type === 'entity.too.large') {
      return res.status(413).json({ error: 'Request body is too large.' })
    }
    return res.status(500).json({ error: 'An unexpected server error occurred.' })
  })

  return app
}
