import path from 'node:path'
import { fileURLToPath } from 'node:url'

const backendDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const projectDirectory = path.resolve(backendDirectory, '..')

const safeConfigMessages = new Set([
  'MAIN_SITE_URL must be an absolute site URL.',
  'MAIN_SITE_URL must be an HTTPS origin (or a localhost origin in development).',
  'PAYMENT_SITE_URL must be an absolute site URL.',
  'PAYMENT_SITE_URL must be an HTTPS origin (or a localhost origin in development).',
  'CASHFREE_WEBHOOK_URL must be an absolute HTTPS URL.',
  'CASHFREE_WEBHOOK_URL must be a public HTTPS URL ending in /api/webhooks/cashfree.',
  'CASHFREE_API_VERSION must use the documented YYYY-MM-DD format.',
  'This integration is validated for Cashfree API version 2026-01-01.',
  'This payment tester is configured for Cashfree PRODUCTION only.',
  'PORT must be an integer from 1 to 65535.',
])

function safeErrorType(error) {
  const name = typeof error?.name === 'string' ? error.name : 'Error'
  return /^[A-Za-z][A-Za-z0-9]*$/.test(name) ? name : 'Error'
}

function safeErrorCode(error) {
  return typeof error?.code === 'string' && /^[A-Z0-9_]+$/.test(error.code)
    ? error.code
    : ''
}

function projectPathIfSafe(candidate) {
  if (typeof candidate !== 'string' || !path.isAbsolute(candidate)) return ''
  const resolved = path.resolve(candidate)
  const relative = path.relative(projectDirectory, resolved)
  if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) return ''
  return resolved
}

function describeFailure(error, stage, context) {
  const code = safeErrorCode(error)

  if (stage === 'backend environment') {
    const message = code === 'EACCES' || code === 'EPERM'
      ? 'Access to the backend environment file was denied; check its permissions.'
      : 'Could not load the backend environment file; check that backend/.env is readable and valid.'
    return { message, filePath: context.envFile }
  }

  if (stage === 'configuration') {
    const message = safeConfigMessages.has(error?.message)
      ? error.message
      : 'Backend configuration validation failed; check the named settings in backend/.env.'
    return { message, filePath: context.envFile }
  }

  if (stage === 'local order store') {
    let message = 'Could not initialize the local order store.'
    if (error?.name === 'SyntaxError') {
      message = 'The local order store contains invalid JSON; inspect or restore the store file.'
    } else if (error?.message === 'The local order store has an unsupported or invalid format.') {
      message = error.message
    } else if (code === 'EACCES' || code === 'EPERM' || code === 'EROFS') {
      message = 'The local order store is not writable; check file and directory permissions.'
    } else if (code === 'ENOSPC') {
      message = 'The local order store could not be written because the disk is full.'
    } else if (code === 'ENOTDIR' || code === 'EISDIR') {
      message = 'The configured order store path is not a usable file path.'
    }
    return { message, filePath: projectPathIfSafe(context.storePath) }
  }

  if (stage === 'API listener') {
    if (code === 'EADDRINUSE') {
      return {
        message: `Port ${context.port} is already in use on 127.0.0.1; stop the other process or configure a different PORT.`,
        filePath: '',
      }
    }
    if (code === 'EACCES' || code === 'EPERM') {
      return { message: `Permission was denied while binding 127.0.0.1:${context.port}.`, filePath: '' }
    }
  }

  return { message: `Unexpected failure during ${stage}; sensitive error details were suppressed.`, filePath: '' }
}

export function formatStartupError(error, stage, context = {}) {
  const type = safeErrorType(error)
  const code = safeErrorCode(error)
  const detail = describeFailure(error, stage, context)
  const codeSuffix = code ? `, ${code}` : ''
  const pathSuffix = detail.filePath ? ` File: ${detail.filePath}.` : ''
  return `Deskpay API startup failed during ${stage} (${type}${codeSuffix}): ${detail.message}${pathSuffix}`
}
