import dotenv from 'dotenv'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const backendDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
export const BACKEND_ENV_FILE = path.join(backendDirectory, '.env')

export function loadBackendEnvironment({ env = process.env, envFile = BACKEND_ENV_FILE } = {}) {
  const result = dotenv.config({
    path: envFile,
    processEnv: env,
    override: true,
    quiet: true,
  })
  const values = result.parsed || {}

  // Cashfree production credentials must come from the backend-local .env only.
  env.CASHFREE_CLIENT_ID = values.CASHFREE_CLIENT_ID?.trim() || ''
  env.CASHFREE_CLIENT_SECRET = values.CASHFREE_CLIENT_SECRET?.trim() || ''

  if (result.error && result.error.code !== 'ENOENT') throw result.error
  return result
}
