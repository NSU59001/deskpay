import { randomUUID } from 'node:crypto'

export const CASHFREE_PRODUCTION_API = 'https://api.cashfree.com'

export class CashfreeError extends Error {
  constructor(status, message = 'Cashfree returned an error.') {
    super(message)
    this.name = 'CashfreeError'
    this.status = status
  }
}

async function requestCashfree({ config, fetchImpl, method, path, body }) {
  const headers = {
    Accept: 'application/json',
    'x-api-version': config.cashfreeApiVersion,
    'x-client-id': config.cashfreeClientId,
    'x-client-secret': config.cashfreeClientSecret,
  }
  if (body) {
    headers['Content-Type'] = 'application/json'
    headers['x-idempotency-key'] = randomUUID()
  }

  let response
  try {
    response = await fetchImpl(`${CASHFREE_PRODUCTION_API}/pg${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(15_000),
    })
  } catch {
    throw new CashfreeError(0, 'Cashfree could not be reached.')
  }

  let data
  try {
    data = await response.json()
  } catch {
    data = null
  }

  if (!response.ok) {
    throw new CashfreeError(response.status)
  }
  return data
}

export function createCashfreeClient({ config, fetchImpl = globalThis.fetch }) {
  return {
    createOrder(order) {
      return requestCashfree({
        config,
        fetchImpl,
        method: 'POST',
        path: '/orders',
        body: order,
      })
    },
    getOrder(orderId) {
      return requestCashfree({
        config,
        fetchImpl,
        method: 'GET',
        path: `/orders/${encodeURIComponent(orderId)}`,
      })
    },
    getPayments(orderId) {
      return requestCashfree({
        config,
        fetchImpl,
        method: 'GET',
        path: `/orders/${encodeURIComponent(orderId)}/payments`,
      })
    },
  }
}
