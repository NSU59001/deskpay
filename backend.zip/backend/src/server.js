import { BACKEND_ENV_FILE, loadBackendEnvironment } from './environment.js'
import { createApp } from './app.js'
import { loadConfig } from './config.js'
import { FileOrderStore } from './store.js'
import { formatStartupError } from './startup-error.js'

async function start() {
  let stage = 'backend environment'
  let config
  let store
  try {
    loadBackendEnvironment()
    stage = 'configuration'
    config = loadConfig()
    stage = 'local order store'
    store = new FileOrderStore(config.dataFile)
    await store.initialize()
    stage = 'API listener'
    const app = createApp({ config, store })
    const server = app.listen(config.port, config.host)
    try {
      await new Promise((resolve, reject) => {
        server.once('listening', resolve)
        server.once('error', reject)
      })
    } catch (error) {
      server.close()
      throw error
    }
    process.stdout.write(`Deskpay API listening on http://${config.host}:${config.port}\n`)

    const shutdown = () => {
      server.close(() => process.exit(0))
    }
    process.on('SIGINT', shutdown)
    process.on('SIGTERM', shutdown)
  } catch (error) {
    process.stderr.write(`${formatStartupError(error, stage, {
      envFile: BACKEND_ENV_FILE,
      storePath: config?.dataFile,
      port: config?.port,
    })}\n`)
    process.exitCode = 1
  }
}

await start()
