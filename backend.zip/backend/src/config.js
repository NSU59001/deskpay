import path from 'node:path'
import { fileURLToPath } from 'node:url'

export const DOCUMENTED_CASHFREE_API_VERSION = '2026-01-01'
export const CHECKOUT_REFERENCE_TTL_MS = 2 * 60 * 60 * 1000
export const CHECKOUT_STATUS_RETENTION_MS = 30 * 24 * 60 * 60 * 1000

const backendDirectory = path.dirname(fileURLToPath(import.meta.url))
const localOrigins = [
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:5174',
  'http://127.0.0.1:5174',
]

function parseSiteUrl(value, name, nodeEnv) {
  let parsed
  try {
    parsed = new URL(value)
  } catch {
    throw new Error(`${name} must be an absolute site URL.`)
  }

  const isLocalHttp =
    nodeEnv !== 'production' &&
    parsed.protocol === 'http:' &&
    ['localhost', '127.0.0.1'].includes(parsed.hostname)

  if (
    (!isLocalHttp && parsed.protocol !== 'https:') ||
    parsed.username ||
    parsed.password ||
    parsed.pathname !== '/' ||
    parsed.search ||
    parsed.hash
  ) {
    throw new Error(`${name} must be an HTTPS origin (or a localhost origin in development).`)
  }

  return parsed.origin
}

function isValidApiVersion(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const parsed = new Date(`${value}T00:00:00.000Z`)
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value
}

function parseIps(value) {
  return new Set(
    value
      .split(',')
      .map((address) => address.trim().replace(/^::ffff:/i, ''))
      .filter(Boolean),
  )
}

function parseWebhookUrl(value) {
  const webhookUrl = value?.trim() || ''
  if (!webhookUrl) return ''

  let parsed
  try {
    parsed = new URL(webhookUrl)
  } catch {
    throw new Error('CASHFREE_WEBHOOK_URL must be an absolute HTTPS URL.')
  }

  if (
    parsed.protocol !== 'https:' ||
    parsed.username ||
    parsed.password ||
    parsed.pathname !== '/api/webhooks/cashfree' ||
    parsed.search ||
    parsed.hash ||
    ['localhost', '127.0.0.1', '::1'].includes(parsed.hostname)
  ) {
    throw new Error('CASHFREE_WEBHOOK_URL must be a public HTTPS URL ending in /api/webhooks/cashfree.')
  }

  return parsed.toString()
}

export function loadConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development'
  const mainSiteUrl = parseSiteUrl(env.MAIN_SITE_URL || 'https://deskpay.in', 'MAIN_SITE_URL', nodeEnv)
  const paymentSiteUrl = parseSiteUrl(
    env.PAYMENT_SITE_URL || 'https://pay.deskpay.in',
    'PAYMENT_SITE_URL',
    nodeEnv,
  )
  const requestedApiVersion = env.CASHFREE_API_VERSION?.trim() || ''
  const cashfreeApiVersion = requestedApiVersion || DOCUMENTED_CASHFREE_API_VERSION

  if (!isValidApiVersion(cashfreeApiVersion)) {
    throw new Error('CASHFREE_API_VERSION must use the documented YYYY-MM-DD format.')
  }
  if (cashfreeApiVersion !== DOCUMENTED_CASHFREE_API_VERSION) {
    throw new Error(`This integration is validated for Cashfree API version ${DOCUMENTED_CASHFREE_API_VERSION}.`)
  }

  const cashfreeEnv = (env.CASHFREE_ENV || 'PRODUCTION').trim().toUpperCase()
  if (cashfreeEnv !== 'PRODUCTION') {
    throw new Error('This payment tester is configured for Cashfree PRODUCTION only.')
  }

  const port = Number(env.PORT || 3000)
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT must be an integer from 1 to 65535.')
  }

  const origins = new Set([mainSiteUrl, paymentSiteUrl])
  if (nodeEnv !== 'production') {
    for (const origin of localOrigins) origins.add(origin)
  }

  return {
    nodeEnv,
    port,
    host: '127.0.0.1',
    mainSiteUrl,
    paymentSiteUrl,
    cashfreeWebhookUrl: parseWebhookUrl(env.CASHFREE_WEBHOOK_URL),
    allowedOrigins: origins,
    cashfreeClientId: env.CASHFREE_CLIENT_ID?.trim() || '',
    cashfreeClientSecret: env.CASHFREE_CLIENT_SECRET?.trim() || '',
    cashfreeApiVersion,
    cashfreeApiVersionProvided: Boolean(requestedApiVersion),
    cashfreeEnv,
    checkoutReferenceSecret: env.CHECKOUT_REFERENCE_SECRET || '',
    orderCreationAllowedIps: parseIps(env.ORDER_CREATION_ALLOWED_IPS || '127.0.0.1,::1'),
    dataFile: env.DATA_FILE
      ? path.resolve(env.DATA_FILE)
      : path.join(backendDirectory, '..', 'data', 'orders.json'),
  }
}
