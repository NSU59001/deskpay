# DeskPay Shop

A lightweight storefront and order-verification demo, split into a static React/Vite frontend and a small Express API. The same 60-product catalog in `backend/catalog.json` supplies the storefront and the server's authoritative price checks.

> **Payment demo only:** the Google Pay-branded button simulates a payment and does not collect money or call Google Pay. Connect a real payment provider, server-side credentials, and verified payment callbacks before accepting live orders.

## Requirements

- Node.js 18 or newer
- npm
- PM2 is optional for local development and required only for the included PM2 deployment command

## Run locally

In one terminal:

```powershell
cd backend
npm install
Copy-Item .env.example .env
npm start
```

In another terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`). The Vite development proxy forwards `/api` requests to `http://localhost:4000`.

To use a different local API target, set `VITE_API_PROXY_TARGET` before starting Vite. For a separately hosted API in a production build, set `VITE_API_BASE_URL` when running `npm run build`; otherwise the frontend uses same-origin `/api` requests.

## Production

Build the static frontend:

```powershell
cd frontend
npm ci
npm run build
```

Serve `frontend/dist/` with Nginx; [frontend/nginx.conf](./frontend/nginx.conf) is a small site configuration that serves static assets and proxies `/api/` to the local Node process. Configure TLS at Nginx or the upstream load balancer. For a separate API origin, build with `VITE_API_BASE_URL=https://api.example.com` and set `FRONTEND_ORIGIN` to the exact storefront origin on the API. Use HTTPS and keep secrets out of the frontend build.

For a single-process PM2 deployment from `backend/`:

```powershell
npm ci
pm2 start ecosystem.config.cjs
```

The PM2 configuration uses one forked process, sets a 64 MB V8 heap limit, and restarts the process if its total resident memory exceeds 100 MB. The production storefront origin is set to `https://example.com` in that configuration; adjust it for the actual deployment before starting.

## API

`POST /api/verify-payment` accepts the unique order ID, item IDs and quantities, and the paise-denominated bill from the storefront. The server looks up prices in the shared catalog, recalculates GST (18%), shipping (₹50 up to and including ₹500 subtotal; free above ₹500), and the final amount. A mismatch or malformed item is rejected. Successfully accepted demo transactions are kept in a bounded in-memory log; no payment-card details are accepted or stored.

Sample request:

```json
{
  "orderId": "#DP-2026-12345",
  "items": [{ "id": "el-001", "quantity": 1 }],
  "billing": {
    "subtotalPaise": 329900,
    "gstPaise": 59382,
    "shippingPaise": 0,
    "totalPaise": 389282
  }
}
```

`GET /api/health` returns a minimal readiness response. Configure `PORT` and `FRONTEND_ORIGIN` via the backend environment.

## Project structure

```text
backend/      Express API, PM2 configuration, and shared catalog
frontend/     React, TypeScript, Vite, and static build
```
