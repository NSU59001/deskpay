module.exports = {
  apps: [
    {
      name: "deskpay-shop-api",
      script: "src/server.js",
      cwd: __dirname,
      instances: 1,
      exec_mode: "fork",
      max_memory_restart: "100M",
      node_args: "--max-old-space-size=64",
      env: {
        NODE_ENV: "production",
        PORT: 4000,
        FRONTEND_ORIGIN: "https://example.com",
      },
    },
  ],
};
