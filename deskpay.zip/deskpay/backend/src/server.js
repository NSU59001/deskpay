"use strict";

const { randomUUID } = require("node:crypto");
const path = require("node:path");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });
const express = require("express");
const cors = require("cors");
const catalog = require("../catalog.json");

const PORT = Number.parseInt(process.env.PORT || "4000", 10);
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";
const FREE_SHIPPING_THRESHOLD_PAISE = 50_000;
const SHIPPING_FEE_PAISE = 5_000;
const MAX_TRANSACTIONS = 1_000;
const ORDER_ID_PATTERN = /^#DP-\d{4}-\d{5}$/;
const productsById = new Map(catalog.map((product) => [product.id, product]));
const transactions = [];

const app = express();
app.disable("x-powered-by");
app.use(cors({ origin: FRONTEND_ORIGIN, methods: ["GET", "POST"], optionsSuccessStatus: 204 }));
app.use(express.json({ limit: "16kb", strict: true }));

app.get("/api/health", (_request, response) => {
  response.json({ success: true });
});

app.post("/api/verify-payment", (request, response) => {
  const { orderId, items, billing } = request.body ?? {};
  if (typeof orderId !== "string" || !ORDER_ID_PATTERN.test(orderId)) {
    return response.status(400).json({ success: false, message: "A valid order ID is required." });
  }
  if (!Array.isArray(items) || items.length === 0 || items.length > catalog.length) {
    return response.status(400).json({ success: false, message: "The order must contain valid items." });
  }
  if (!billing || typeof billing !== "object" || Array.isArray(billing)) {
    return response.status(400).json({ success: false, message: "Valid billing details are required." });
  }

  const seenProductIds = new Set();
  let subtotalPaise = 0;
  for (const item of items) {
    if (
      !item ||
      typeof item !== "object" ||
      typeof item.id !== "string" ||
      !Number.isSafeInteger(item.quantity) ||
      item.quantity < 1 ||
      item.quantity > 99 ||
      seenProductIds.has(item.id)
    ) {
      return response.status(400).json({ success: false, message: "The order contains an invalid item." });
    }
    const product = productsById.get(item.id);
    if (!product) {
      return response.status(400).json({ success: false, message: "The order contains an unavailable product." });
    }
    seenProductIds.add(item.id);
    subtotalPaise += product.basePrice * item.quantity * 100;
  }

  const gstPaise = Math.round((subtotalPaise * 18) / 100);
  const shippingPaise = subtotalPaise > FREE_SHIPPING_THRESHOLD_PAISE ? 0 : SHIPPING_FEE_PAISE;
  const totalPaise = subtotalPaise + gstPaise + shippingPaise;
  const submittedBilling = [
    billing.subtotalPaise,
    billing.gstPaise,
    billing.shippingPaise,
    billing.totalPaise,
  ];
  const calculatedBilling = [subtotalPaise, gstPaise, shippingPaise, totalPaise];

  if (
    submittedBilling.some((amount, index) =>
      !Number.isSafeInteger(amount) || amount !== calculatedBilling[index],
    )
  ) {
    return response.status(400).json({ success: false, message: "The order total could not be verified. Please refresh and try again." });
  }
  if (transactions.some((transaction) => transaction.orderId === orderId)) {
    return response.status(409).json({ success: false, message: "This order has already been placed." });
  }

  const transactionId = `TXN_ECOM_${randomUUID().replaceAll("-", "").slice(0, 12).toUpperCase()}`;
  transactions.push({
    orderId,
    transactionId,
    totalPaise,
    createdAt: new Date().toISOString(),
  });
  if (transactions.length > MAX_TRANSACTIONS) transactions.shift();

  console.info(JSON.stringify({ event: "order.placed", orderId, transactionId }));
  return response.status(200).json({
    success: true,
    message: "DeskPay Shop order placed successfully",
    transactionId,
  });
});

app.use((error, _request, response, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    return response.status(400).json({ success: false, message: "Request body must be valid JSON." });
  }
  if (error.type === "entity.too.large") {
    return response.status(413).json({ success: false, message: "Request body exceeds the 16 KB limit." });
  }
  console.error("Request failed:", error.message);
  return response.status(500).json({ success: false, message: "An unexpected server error occurred." });
});

const server = app.listen(PORT, "0.0.0.0", () => {
  console.info(`DeskPay Shop API listening on port ${PORT}`);
});

function shutdown() {
  server.close((error) => {
    if (error) {
      console.error("Server shutdown failed:", error.message);
      process.exitCode = 1;
    }
  });
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
