import { useCallback, useEffect, useMemo, useState } from "react";
import { categories, products } from "./catalog";
import { calculateBill, createOrderId, formatRupees } from "./billing";
import type { CartItem, PaymentResult, Product } from "./types";

type Screen = "catalog" | "checkout" | "success";
type PaymentState = "idle" | "processing" | "error";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [screen, setScreen] = useState<Screen>("catalog");
  const [orderId, setOrderId] = useState(createOrderId);
  const [paymentState, setPaymentState] = useState<PaymentState>("idle");
  const [paymentError, setPaymentError] = useState("");
  const [googlePayReady, setGooglePayReady] = useState(false);
  const [googlePayError, setGooglePayError] = useState("");
  const [googlePayContainer, setGooglePayContainer] = useState<HTMLDivElement | null>(null);
  const [receipt, setReceipt] = useState<{
    orderId: string;
    transactionId: string;
    items: CartItem[];
  } | null>(null);

  const visibleProducts = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    return products.filter((product) => {
      const matchesCategory =
        activeCategory === "All" || product.category === activeCategory;
      const matchesQuery =
        query.length === 0 ||
        product.title.toLocaleLowerCase().includes(query) ||
        product.category.toLocaleLowerCase().includes(query);
      return matchesCategory && matchesQuery;
    });
  }, [activeCategory, search]);

  const bill = useMemo(() => calculateBill(cart), [cart]);
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  function addToCart(product: Product) {
    setCart((current) => {
      const existing = current.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= 99) return current;
        return current.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item,
        );
      }
      return [...current, { product, quantity: 1 }];
    });
  }

  function changeQuantity(productId: string, change: number) {
    setCart((current) =>
      current
        .map((item) =>
          item.product.id === productId
            ? { ...item, quantity: Math.min(99, item.quantity + change) }
            : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }

  function removeItem(productId: string) {
    setCart((current) => current.filter((item) => item.product.id !== productId));
  }

  const startPayment = useCallback(async () => {
    if (cart.length === 0 || paymentState === "processing") return;

    setPaymentError("");
    setPaymentState("processing");
    await new Promise<void>((resolve) => window.setTimeout(resolve, 3000));

    const orderedItems = cart.map(({ product, quantity }) => ({
      id: product.id,
      quantity,
    }));

    try {
      const response = await fetch(`${API_BASE_URL}/api/verify-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          items: orderedItems,
          billing: bill,
        }),
      });

      const payload: unknown = await response.json();
      if (!response.ok) {
        const message =
          typeof payload === "object" &&
          payload !== null &&
          "message" in payload &&
          typeof payload.message === "string"
            ? payload.message
            : "We couldn't verify this order. Please try again.";
        throw new Error(message);
      }

      if (!isPaymentResult(payload)) {
        throw new Error("The server returned an invalid payment confirmation.");
      }

      setReceipt({
        orderId,
        transactionId: payload.transactionId,
        items: cart,
      });
      setCart([]);
      setPaymentState("idle");
      setScreen("success");
    } catch (error) {
      setPaymentError(
        error instanceof Error
          ? error.message
          : "Payment verification failed. Please try again.",
      );
      setPaymentState("error");
    }
  }, [bill, cart, orderId, paymentState]);

  useEffect(() => {
    if (window.google?.payments?.api?.PaymentsClient) {
      setGooglePayReady(true);
      return;
    }

    const script = document.querySelector<HTMLScriptElement>("script[data-google-pay-sdk]");
    if (!script) {
      setGooglePayError("The Google Pay button could not be loaded. Please refresh and try again.");
      return;
    }

    const handleLoad = () => {
      if (window.google?.payments?.api?.PaymentsClient) {
        setGooglePayReady(true);
      } else {
        setGooglePayError("The Google Pay button could not be loaded. Please refresh and try again.");
      }
    };
    const handleError = () => {
      setGooglePayError("The Google Pay button could not be loaded. Please refresh and try again.");
    };

    script.addEventListener("load", handleLoad);
    script.addEventListener("error", handleError);
    return () => {
      script.removeEventListener("load", handleLoad);
      script.removeEventListener("error", handleError);
    };
  }, []);

  useEffect(() => {
    if (!googlePayReady || !googlePayContainer) return;
    const PaymentsClient = window.google?.payments?.api?.PaymentsClient;
    if (!PaymentsClient) {
      setGooglePayError("The Google Pay button could not be loaded. Please refresh and try again.");
      return;
    }

    try {
      const client = new PaymentsClient({ environment: "TEST" });
      const button = client.createButton({
        onClick: () => void startPayment(),
        buttonColor: "black",
        buttonType: "buy",
        buttonSizeMode: "fill",
      });
      googlePayContainer.replaceChildren(button);
    } catch (error) {
      setGooglePayError(
        error instanceof Error
          ? `The Google Pay button could not be created: ${error.message}`
          : "The Google Pay button could not be created.",
      );
    }
  }, [googlePayContainer, googlePayReady, startPayment]);

  function beginNewOrder() {
    setOrderId(createOrderId());
    setReceipt(null);
    setPaymentState("idle");
    setPaymentError("");
    setScreen("catalog");
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <a
          className="wordmark"
          href="#top"
          onClick={(event) => {
            event.preventDefault();
            setScreen("catalog");
          }}
          aria-label="DeskPay Shop home"
        >
          DeskPay Shop
        </a>
        <span className="header-note">A little more considered.</span>
        <button
          className={`cart-trigger${screen === "checkout" ? " is-active" : ""}`}
          type="button"
          onClick={() => setScreen(screen === "checkout" ? "catalog" : "checkout")}
          aria-label={`Shopping bag, ${cartCount} items`}
        >
          <span className="bag-icon" aria-hidden="true">▱</span>
          <span>Bag</span>
          <span className="cart-count">{cartCount}</span>
        </button>
      </header>

      {screen === "catalog" && (
        <main id="top" className="main-content">
          <section className="hero">
            <div className="hero-copy">
              <span className="eyebrow">THE EVERYDAY EDIT · VOL. 01</span>
              <h1>Good things.<br />Chosen with care.</h1>
              <p>Thoughtful finds for slower mornings, brighter spaces, and all the little moments in between.</p>
              <a className="text-link" href="#collection">Explore the collection <span aria-hidden="true">↘</span></a>
            </div>
            <div className="hero-art" aria-label="A considered collection of everyday essentials" role="img">
              <span className="art-sun" />
              <span className="art-vase art-vase-one" />
              <span className="art-vase art-vase-two" />
              <span className="art-stem art-stem-one" />
              <span className="art-stem art-stem-two" />
              <span className="art-caption">objects for<br />the everyday</span>
              <span className="art-edition">EST. 2026 &nbsp;·&nbsp; MADE TO KEEP</span>
            </div>
          </section>

          <section id="collection" className="collection-section">
            <div className="section-heading">
              <div>
                <span className="eyebrow">A GOOD PLACE TO START</span>
                <h2>The collection</h2>
              </div>
              <label className="search-box">
                <span className="search-icon" aria-hidden="true">⌕</span>
                <input
                  type="search"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Find something..."
                  aria-label="Search products"
                />
              </label>
            </div>

            <div className="catalog-toolbar">
              <div className="category-list" aria-label="Filter by category">
                {categories.map((category) => (
                  <button
                    className={`category-chip${activeCategory === category ? " selected" : ""}`}
                    type="button"
                    key={category}
                    onClick={() => setActiveCategory(category)}
                    aria-pressed={activeCategory === category}
                  >
                    {category}
                  </button>
                ))}
              </div>
              <span className="result-count">{visibleProducts.length} pieces</span>
            </div>

            {visibleProducts.length > 0 ? (
              <div className="product-grid">
                {visibleProducts.map((product, index) => {
                  const quantity =
                    cart.find((item) => item.product.id === product.id)?.quantity ?? 0;
                  return (
                    <article className="product-card" key={product.id}>
                      <div className={`product-image-wrap tone-${index % 4}`}>
                        <img
                          className="product-image"
                          src={product.imageUrl}
                          alt={product.title}
                          loading="lazy"
                          width="640"
                          height="480"
                        />
                        <span className="product-category">{product.category}</span>
                        <button
                          className={`add-button${quantity > 0 ? " added" : ""}`}
                          type="button"
                          onClick={() => addToCart(product)}
                          aria-label={quantity >= 99 ? `Maximum quantity reached for ${product.title}` : `Add ${product.title} to bag`}
                          disabled={quantity >= 99}
                        >
                          {quantity > 0 ? `+ ${quantity}` : "+"}
                        </button>
                      </div>
                      <div className="product-info">
                        <h3>{product.title}</h3>
                        <span>{formatRupees(product.basePrice * 100)}</span>
                      </div>
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="empty-search">
                <span className="empty-symbol">○</span>
                <h3>Nothing on this shelf</h3>
                <p>Try another search or explore a different category.</p>
                <button
                  className="text-link-button"
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setActiveCategory("All");
                  }}
                >
                  Clear filters <span aria-hidden="true">↗</span>
                </button>
              </div>
            )}
          </section>
        </main>
      )}

      {screen === "checkout" && (
        <main className="checkout-page">
          <button className="back-link" type="button" onClick={() => setScreen("catalog")}>
            <span aria-hidden="true">←</span> Continue browsing
          </button>
          <div className="checkout-layout">
            <section className="checkout-main">
              <span className="eyebrow">DESKPAY SHOP · SECURE CHECKOUT</span>
              <h1>Your DeskPay bag.</h1>
              {cart.length === 0 ? (
                <div className="empty-bag">
                  <span className="empty-symbol">▱</span>
                  <h2>It's looking a little light.</h2>
                  <p>Find something lovely in the collection.</p>
                  <button className="primary-button" type="button" onClick={() => setScreen("catalog")}>
                    Explore the collection <span aria-hidden="true">↗</span>
                  </button>
                </div>
              ) : (
                <div className="checkout-items">
                  {cart.map(({ product, quantity }) => (
                    <article className="checkout-item" key={product.id}>
                      <img src={product.imageUrl} alt="" width="640" height="480" />
                      <div className="checkout-item-copy">
                        <span className="eyebrow">{product.category}</span>
                        <h2>{product.title}</h2>
                        <span className="item-price">{formatRupees(product.basePrice * 100)}</span>
                        <div className="quantity-control" aria-label={`Quantity for ${product.title}`}>
                          <button
                            type="button"
                            onClick={() => changeQuantity(product.id, -1)}
                            aria-label={`Remove one ${product.title}`}
                          >−</button>
                          <span>{quantity}</span>
                          <button
                            type="button"
                            onClick={() => changeQuantity(product.id, 1)}
                            aria-label={`Add one ${product.title}`}
                            disabled={quantity >= 99}
                          >+</button>
                        </div>
                      </div>
                      <button
                        className="remove-button"
                        type="button"
                        onClick={() => removeItem(product.id)}
                        aria-label={`Remove ${product.title} from bag`}
                      >Remove</button>
                    </article>
                  ))}
                </div>
              )}
            </section>

            {cart.length > 0 && (
              <aside className="order-card" aria-label="Order summary">
                <div className="order-card-heading">
                  <span className="eyebrow">YOUR ORDER</span>
                  <span className="order-id">{orderId}</span>
                </div>
                <div className="order-lines">
                  <div><span>Items subtotal</span><span>{formatRupees(bill.subtotalPaise)}</span></div>
                  <div><span>GST <small>(18%)</small></span><span>{formatRupees(bill.gstPaise)}</span></div>
                  <div>
                    <span>Shipping</span>
                    <span>{bill.shippingPaise === 0 ? <span className="free-shipping">On us</span> : formatRupees(bill.shippingPaise)}</span>
                  </div>
                </div>
                {bill.shippingPaise > 0 && (
                  <p className="shipping-note">A little more? Shipping is on us over ₹500.</p>
                )}
                <div className="total-line"><span>Total to pay</span><strong>{formatRupees(bill.totalPaise)}</strong></div>
                <div className="tax-note">Inclusive of GST · All prices in INR</div>
                <div className="payment-divider"><span>PAY SECURELY WITH</span></div>
                {googlePayError ? (
                  <p className="gpay-error" role="alert">{googlePayError}</p>
                ) : (
                  <div
                    className="gpay-button-container"
                    ref={setGooglePayContainer}
                    aria-label="Buy with Google Pay"
                  >
                    {!googlePayReady && <span className="gpay-loading">Loading Google Pay…</span>}
                  </div>
                )}
                <p className="demo-disclosure">Demo payment simulation — no real payment is collected.</p>
                <div className="secure-note"><span aria-hidden="true">◇</span> Your details stay yours. Always.</div>
              </aside>
            )}
          </div>
        </main>
      )}

      {screen === "success" && receipt && (
        <main className="receipt-page">
          <div className="receipt-card">
            <div className="success-mark" aria-hidden="true">✓</div>
            <span className="eyebrow">DESKPAY SHOP · ALL WRAPPED UP</span>
            <h1>Payment<br />successful.</h1>
            <p className="receipt-intro">A little something lovely is on its way to you.</p>
            <div className="receipt-order">
              <span>Order</span><strong>{receipt.orderId}</strong>
              <span>Transaction</span><strong>{receipt.transactionId}</strong>
            </div>
            <div className="receipt-items">
              {receipt.items.map(({ product, quantity }) => (
                <div className="receipt-item" key={product.id}>
                  <span>{product.title} <small>× {quantity}</small></span>
                  <span>{formatRupees(product.basePrice * quantity * 100)}</span>
                </div>
              ))}
            </div>
            <div className="receipt-totals">
              {(() => {
                const paidBill = calculateBill(receipt.items);
                return (
                  <>
                    <div><span>Items subtotal</span><span>{formatRupees(paidBill.subtotalPaise)}</span></div>
                    <div><span>GST <small>(18%)</small></span><span>{formatRupees(paidBill.gstPaise)}</span></div>
                    <div><span>Shipping</span><span>{paidBill.shippingPaise === 0 ? "On us" : formatRupees(paidBill.shippingPaise)}</span></div>
                    <div className="receipt-total"><span>Paid in full</span><strong>{formatRupees(paidBill.totalPaise)}</strong></div>
                  </>
                );
              })()}
            </div>
            <button className="primary-button receipt-continue" type="button" onClick={beginNewOrder}>
              Back to the good things <span aria-hidden="true">↗</span>
            </button>
            <p className="receipt-thanks">Thank you for shopping small and thoughtfully.</p>
          </div>
        </main>
      )}

      <footer className="site-footer">
        <a className="footer-wordmark" href="#top" onClick={(event) => event.preventDefault()}>DeskPay Shop</a>
        <span>Thoughtfully chosen. Made for keeping.</span>
        <span>© {new Date().getFullYear()} DeskPay Shop</span>
      </footer>

      {paymentState !== "idle" && (
        <div
          className="modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget && paymentState === "error") {
              setPaymentState("idle");
            }
          }}
        >
          <section
            className={`payment-modal${paymentState === "error" ? " has-error" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-labelledby="payment-modal-title"
            aria-live="polite"
          >
            {paymentState === "processing" ? (
              <>
                <div className="payment-orbit"><span /><span /><span /></div>
                <span className="eyebrow">A MOMENT, PLEASE</span>
                <h2 id="payment-modal-title">Making it yours.</h2>
                <p>Securely checking the details of your order.</p>
                <div className="processing-steps">
                  <span className="step-active"><i /> Preparing your order</span>
                  <span><i /> Verifying your payment</span>
                </div>
                <span className="modal-order">Order {orderId}</span>
              </>
            ) : (
              <>
                <div className="error-mark" aria-hidden="true">!</div>
                <span className="eyebrow">NOT QUITE YET</span>
                <h2 id="payment-modal-title">We couldn't place that order.</h2>
                <p className="payment-error" role="alert">{paymentError}</p>
                <button className="primary-button retry-button" type="button" onClick={startPayment}>
                  Try again <span aria-hidden="true">↗</span>
                </button>
                <button className="text-link-button close-error" type="button" onClick={() => setPaymentState("idle")}>
                  Back to your order
                </button>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

function isPaymentResult(payload: unknown): payload is PaymentResult {
  return (
    typeof payload === "object" &&
    payload !== null &&
    "success" in payload &&
    payload.success === true &&
    "message" in payload &&
    typeof payload.message === "string" &&
    "transactionId" in payload &&
    typeof payload.transactionId === "string"
  );
}

export default App;
