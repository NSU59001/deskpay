export type Product = {
  id: string;
  title: string;
  basePrice: number;
  category: string;
  imageUrl: string;
};

export type CartItem = {
  product: Product;
  quantity: number;
};

export type Bill = {
  subtotalPaise: number;
  gstPaise: number;
  shippingPaise: number;
  totalPaise: number;
};

export type PaymentResult = {
  success: true;
  message: string;
  transactionId: string;
};
