import type { Bill, CartItem } from "./types";

export function calculateBill(items: CartItem[]): Bill {
  const subtotalPaise = items.reduce(
    (subtotal, item) => subtotal + item.product.basePrice * item.quantity * 100,
    0,
  );
  const gstPaise = Math.round((subtotalPaise * 18) / 100);
  const shippingPaise = subtotalPaise > 50_000 ? 0 : 5_000;

  return {
    subtotalPaise,
    gstPaise,
    shippingPaise,
    totalPaise: subtotalPaise + gstPaise + shippingPaise,
  };
}

export function formatRupees(paise: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(paise / 100);
}

export function createOrderId(): string {
  const values = new Uint32Array(1);
  crypto.getRandomValues(values);
  const number = values[0] % 100_000;
  return `#DP-${new Date().getFullYear()}-${number.toString().padStart(5, "0")}`;
}
