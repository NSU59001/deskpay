/// <reference types="vite/client" />

type GooglePayButtonOptions = {
  onClick: () => void;
  buttonColor: "black" | "white";
  buttonType: "buy";
  buttonSizeMode: "fill";
};

declare global {
  interface Window {
    google?: {
      payments?: {
        api?: {
          PaymentsClient: new (options: { environment: "TEST" }) => {
            createButton: (options: GooglePayButtonOptions) => HTMLElement;
          };
        };
      };
    };
  }
}

export {};
