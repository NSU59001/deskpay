import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ".", "VITE_");

  return {
    plugins: [react()],
    server: {
      proxy: {
        "/api": {
          target: env.VITE_API_PROXY_TARGET ?? "http://localhost:4000",
          changeOrigin: true,
        },
      },
    },
    build: {
      target: "es2020",
      sourcemap: false,
      cssCodeSplit: true,
    },
  };
});
